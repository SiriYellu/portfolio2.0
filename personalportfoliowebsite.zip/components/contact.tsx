"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Linkedin, Github, Mail, Phone, MapPin, Send } from "lucide-react"
import { useState, useEffect, useRef } from "react"
import { sendEmail } from "@/app/actions/send-email"

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle")
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitStatus("idle")

    try {
      const formDataObj = new FormData()
      formDataObj.append("name", formData.name)
      formDataObj.append("email", formData.email)
      formDataObj.append("message", formData.message)

      const result = await sendEmail(formDataObj)

      if (result.success) {
        window.location.href = result.mailto
        setSubmitStatus("success")
        setFormData({ name: "", email: "", message: "" })
      }
    } catch (error) {
      console.error("Error sending email:", error)
      setSubmitStatus("error")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <section ref={sectionRef} id="contact" className="py-20 sm:py-32 px-4 sm:px-6 lg:px-8 bg-[#0f1419]">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <h2
            className={`text-4xl sm:text-5xl md:text-6xl font-bold mb-4 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            Get In <span className="text-blue-500">Touch</span>
          </h2>
          <div
            className={`w-32 h-1 bg-blue-500 mx-auto rounded-full mb-6 transition-all duration-700 delay-100 ${isVisible ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"}`}
          ></div>
          <p
            className={`text-lg text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left Column - Contact Information */}
          <div
            className={`space-y-8 transition-all duration-700 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"}`}
          >
            <div>
              <h3 className="text-2xl sm:text-3xl font-bold mb-6 text-blue-500">Let's Connect</h3>
              <p className="text-gray-400 mb-8">
                Feel free to reach out through any of the following channels. I typically respond within 24 hours.
              </p>
            </div>

            {/* Contact Info Cards */}
            <div className="space-y-4">
              {/* Email Card */}
              <Card className="bg-[#1a1f2e] border-[#2a3244] hover:border-blue-500/50 transition-all duration-300">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="bg-blue-500/10 p-3 rounded-lg">
                    <Mail className="h-6 w-6 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Email</p>
                    <a
                      href="mailto:syellu@students.kennesaw.edu"
                      className="text-white hover:text-blue-500 transition-colors font-medium"
                    >
                      syellu@students.kennesaw.edu
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Phone Card */}
              <Card className="bg-[#1a1f2e] border-[#2a3244] hover:border-blue-500/50 transition-all duration-300">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="bg-blue-500/10 p-3 rounded-lg">
                    <Phone className="h-6 w-6 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Phone</p>
                    <a href="tel:4708548678" className="text-white hover:text-blue-500 transition-colors font-medium">
                      +1 470 854 8678
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Location Card */}
              <Card className="bg-[#1a1f2e] border-[#2a3244] hover:border-blue-500/50 transition-all duration-300">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="bg-blue-500/10 p-3 rounded-lg">
                    <MapPin className="h-6 w-6 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Location</p>
                    <p className="text-white font-medium">United States</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Social Links */}
            <div className="pt-4">
              <p className="text-gray-400 mb-4">Follow me on</p>
              <div className="flex gap-3">
                <a
                  href="https://www.linkedin.com/in/siri-reddy-yellu/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#1a1f2e] border border-[#2a3244] p-3 rounded-lg hover:bg-blue-500/10 hover:border-blue-500/50 transition-all duration-300"
                >
                  <Linkedin className="h-5 w-5 text-gray-400 hover:text-blue-500" />
                </a>
                <a
                  href="https://github.com/SiriYellu"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#1a1f2e] border border-[#2a3244] p-3 rounded-lg hover:bg-blue-500/10 hover:border-blue-500/50 transition-all duration-300"
                >
                  <Github className="h-5 w-5 text-gray-400 hover:text-blue-500" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Column - Contact Form */}
          <div
            className={`transition-all duration-700 delay-400 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}`}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white">
                  Your Name
                </Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="bg-[#1a1f2e] border-[#2a3244] text-white placeholder:text-gray-500 focus:border-blue-500 h-14"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Your Email
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="john@example.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="bg-[#1a1f2e] border-[#2a3244] text-white placeholder:text-gray-500 focus:border-blue-500 h-14"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-white">
                  Message
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  placeholder="Your message..."
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={8}
                  disabled={isSubmitting}
                  className="bg-[#1a1f2e] border-[#2a3244] text-white placeholder:text-gray-500 focus:border-blue-500 resize-none"
                />
              </div>

              {submitStatus === "success" && (
                <p className="text-sm text-green-500">Your email client will open with the message!</p>
              )}
              {submitStatus === "error" && (
                <p className="text-sm text-red-500">Something went wrong. Please try again or email directly.</p>
              )}

              <Button
                type="submit"
                size="lg"
                className="w-full bg-blue-500 hover:bg-blue-600 text-white h-14 text-base font-medium"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Sending..." : "Send Message"}
                <Send className="ml-2 h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
