"use client"

import { Card, CardContent } from "@/components/ui/card"
import { GraduationCap, TrendingUp, Database } from "lucide-react"
import { useEffect, useRef, useState } from "react"

export function About() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="about"
      className="py-20 sm:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-muted/30 transition-colors duration-700"
    >
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12 sm:mb-16">
          <h2
            className={`text-3xl sm:text-4xl md:text-5xl font-bold mb-4 text-balance transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            About Me
          </h2>
          <div
            className={`w-20 h-1 bg-accent mx-auto rounded-full transition-all duration-700 delay-100 ${isVisible ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"}`}
          ></div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {[
            {
              icon: GraduationCap,
              title: "Academic Excellence",
              description: "MS in Computer Science (Data Science) with 4.0 GPA",
            },
            {
              icon: TrendingUp,
              title: "Machine Learning",
              description: "Predictive modeling and NLP solutions",
            },
            {
              icon: Database,
              title: "Data Analytics",
              description: "Healthcare analytics and visualization",
            },
          ].map((item, index) => (
            <Card
              key={index}
              className={`border-none shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              <CardContent className="pt-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="max-w-4xl mx-auto">
          <Card
            className={`border-none shadow-lg transition-all duration-700 delay-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            <CardContent className="pt-8 pb-8 px-6 sm:px-8">
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed text-pretty">
                I am currently pursuing my MS in Computer Science with a concentration in Data Science at Kennesaw State
                University, maintaining a perfect 4.0 GPA. With a strong foundation in data analytics, machine learning,
                and software development, I specialize in healthcare analytics, natural language processing, dashboard
                development, and predictive modeling. My experience includes building ML pipelines for cancer image
                analysis, developing NLP-powered chatbots, and creating interactive dashboards that transform complex
                data into actionable insights. I am passionate about leveraging technology and data to solve real-world
                challenges and am actively seeking opportunities in Software Engineering, Data Analytics, Machine
                Learning, and Data Science roles.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
