"use client"

import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"
import { useEffect, useState } from "react"
import Image from "next/image"

export function Hero() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 pt-16 overflow-hidden">
      {/* Tech-themed animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5">
        {/* Animated grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_0%,#000_70%,transparent_110%)]" />

        {/* Floating tech particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-primary/30 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${5 + Math.random() * 10}s`,
              }}
            />
          ))}
        </div>

        {/* Glowing orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-slow" />
        <div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse-slow"
          style={{ animationDelay: "2s" }}
        />
      </div>

      <div className="container mx-auto max-w-6xl relative z-10">
        <div className="text-center space-y-6 sm:space-y-8">
          <div
            className="inline-block animate-fade-in-up"
            style={{
              opacity: Math.max(0, 1 - scrollY / 300),
              transform: `translateY(${scrollY * 0.2}px)`,
              transition: "opacity 0.3s ease-out, transform 0.3s ease-out",
            }}
          >
            <div className="relative w-40 h-40 sm:w-48 sm:h-48 mx-auto mb-6 rounded-full overflow-hidden ring-4 ring-primary/20 shadow-2xl animate-profile-float hover:animate-profile-spin hover:ring-primary/60 transition-all duration-500 shadow-primary/30 hover:shadow-primary/50 hover:scale-105">
              <Image src="/images/profile-photo.png" alt="Siri Yellu" fill className="object-cover" priority />
            </div>
          </div>

          <div
            className="space-y-4 animate-fade-in-up"
            style={{
              animationDelay: "0.2s",
              opacity: Math.max(0, 1 - scrollY / 400),
            }}
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-balance">
              Siri Yellu
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-muted-foreground font-medium">
              Graduate Research Assistant | MS in Computer Science (Data Science)
            </p>
            <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
              Data Science, Machine Learning, Analytics
            </p>
          </div>

          <div className="pt-4 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <p className="text-lg sm:text-xl md:text-2xl text-foreground/90 max-w-3xl mx-auto text-balance leading-relaxed">
              Turning data into actionable insights through analytics and machine learning.
            </p>
          </div>

          <div
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6 animate-fade-in-up"
            style={{ animationDelay: "0.6s" }}
          >
            <Button size="lg" asChild className="w-full sm:w-auto">
              <a href="#projects">View Projects</a>
            </Button>
            <Button size="lg" variant="outline" asChild className="w-full sm:w-auto bg-transparent">
              <a href="#contact">Contact</a>
            </Button>
          </div>

          <div className="pt-12 sm:pt-16 animate-bounce">
            <a href="#about" className="inline-block text-muted-foreground hover:text-foreground transition-colors">
              <ArrowDown className="h-6 w-6" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
