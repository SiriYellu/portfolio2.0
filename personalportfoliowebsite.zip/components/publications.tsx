"use client"

import { ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useEffect, useRef, useState } from "react"

const publications = [
  {
    domain: "Healthcare AI & Medical Imaging",
    papers: [
      {
        title:
          "Investigating Spatial Patterns of Tumor and Stroma in Gastric and Colorectal Cancer for Survival Prediction",
        authors: [
          "Sanghoon Lee",
          "Yellu Siri",
          "Sung Hak Lee",
          "Jae-Ho Cheong",
          "Minji Kim",
          "Sunho Park",
          "Tae Hyun Hwang",
        ],
        venue: "IEEE-EMBS BHI 2025",
        summary:
          "Analyzed spatial tumor-stroma patterns in gastric and colorectal cancer to predict patient survival outcomes using deep learning.",
        links: {
          paper: "https://openreview.net/pdf?id=YgzZjvskC8",
        },
      },
      {
        title:
          "Evaluation of Hand-Crafted Features with Mask Images Obtained from PanNuke Dataset Using Bayesian Optimization and Machine Learning Models",
        authors: ["Yellu Siri", "S. C. Koganti", "H. Elghazzali", "Y. Zhao", "D. F. Williamson", "S. Lee"],
        venue: "IEEE ICSC 2025",
        summary:
          "Optimized hand-crafted features for nuclei classification on PanNuke dataset using Bayesian methods and ML models.",
        links: {
          paper: "https://www.computer.org/csdl/proceedings-article/icsc/2025/242600a097/27FQGIfIRHO",
        },
      },
      {
        title:
          "Task-ready PanNuke and NuCLS Datasets: Reorganization, Synthetic Data Generation, and Experimental Evaluation",
        authors: ["S. C. Koganti", "Yellu Siri", "J. Yun", "S. Lee"],
        venue: "IEEE Access",
        summary:
          "Reorganized medical imaging datasets and generated synthetic data to improve nuclei segmentation tasks.",
        links: {
          paper: "https://ieeexplore.ieee.org/abstract/document/11080424/",
        },
      },
      {
        title: "Color Normalization Analysis for Semantic Image Segmentation on Histopathology Images",
        authors: ["V. Yaganti", "S. C. Koganti", "Yellu Siri", "S. Lee"],
        venue: "IEEE SoutheastCon 2025",
        summary:
          "Evaluated color normalization techniques to improve semantic segmentation accuracy on histopathology images.",
        links: {
          paper: "https://ieeexplore.ieee.org/abstract/document/10971522",
        },
      },
    ],
  },
  {
    domain: "Natural Language Processing",
    papers: [
      {
        title:
          "Enhancing Sentiment Analysis Accuracy by Optimizing Hyperparameters of SVM and Logistic Regression Models",
        authors: ["Yellu Siri", "S. Afroz", "R. U. Rani"],
        venue: "E3S Web of Conferences 2024",
        summary:
          "Improved sentiment classification performance through systematic hyperparameter tuning of SVM and logistic regression.",
        links: {
          paper:
            "https://www.e3s-conferences.org/articles/e3sconf/abs/2024/02/e3sconf_icregcsd2023_01017/e3sconf_icregcsd2023_01017.html",
        },
      },
    ],
  },
  {
    domain: "Generative AI",
    papers: [
      {
        title: "Generative Adversarial Quest: Enhancing Question and Answer Generation Through GAN",
        authors: ["Yellu Siri", "C. V. S. Satyamurty", "S. N. Appe"],
        venue: "ICICC 2024",
        summary:
          "Leveraged GANs to automatically generate high-quality question-answer pairs for educational applications.",
        links: {
          paper: "https://books.google.com/books?id=JPd1EQAAQBAJ",
        },
      },
    ],
  },
  {
    domain: "Computer Vision",
    papers: [
      {
        title: "Early Stage Identification of Tomato Leaf Diseases using VGG16 and MobileNet CNNs",
        authors: ["Yellu Siri", "R. Jagarlapudi", "S. T. Salehundam", "K. J. Mohan", "K. V. Sharma"],
        venue: "Macaw International Journal of Advanced Research in Computer Science",
        summary: "Developed CNN-based models for automated early detection of tomato plant diseases from leaf images.",
        links: {
          paper:
            "https://scholar.google.com/citations?view_op=view_citation&hl=en&user=KgZ_LmYAAAAJ&citation_for_view=KgZ_LmYAAAAJ:9yKSN-GCB0IC",
        },
      },
    ],
  },
]

export function Publications() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="publications"
      className="py-20 bg-gradient-to-b from-background to-muted/30 transition-colors duration-700"
    >
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2
            className={`text-4xl font-bold text-foreground mb-4 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            Publications & Research
          </h2>
          <p
            className={`text-muted-foreground text-lg max-w-2xl mx-auto transition-all duration-700 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            Applied AI research with real-world impact across healthcare, NLP, and computer vision
          </p>
        </div>

        <div
          className={`mb-16 grid grid-cols-1 md:grid-cols-3 gap-6 transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl ring-2 ring-primary/20 group">
            <Image
              src="/images/georgia-tech-poster.jpg"
              alt="Siri Yellu presenting research poster at Georgia Tech Global Learning Center"
              width={400}
              height={600}
              className="object-cover w-full h-[400px] transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <p className="text-white text-sm font-medium">Georgia Tech Global Learning Center</p>
            </div>
          </div>

          <div className="relative rounded-2xl overflow-hidden shadow-2xl ring-2 ring-primary/20 group">
            <Image
              src="/images/ieee-conference-2024.jpeg"
              alt="Siri Yellu presenting at 2024 IEEE ICSC Conference in Laguna Hills, CA"
              width={400}
              height={600}
              className="object-cover w-full h-[400px] transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <p className="text-white text-sm font-medium">2024 IEEE ICSC Conference, Laguna Hills, CA</p>
            </div>
          </div>

          <div className="relative rounded-2xl overflow-hidden shadow-2xl ring-2 ring-primary/20 group bg-muted">
            <Image
              src="/images/e3s-conference-2024.jpeg"
              alt="Siri Yellu presenting at E3S Web of Conferences 2024 in India"
              width={400}
              height={600}
              className="object-cover w-full h-[400px] transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <p className="text-white text-sm font-medium">E3S Web of Conferences 2024, India</p>
            </div>
          </div>
        </div>

        {/* Featured Publications */}
        <div className="space-y-12">
          {publications.map((domain, domainIdx) => (
            <div
              key={domainIdx}
              className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
              style={{ transitionDelay: `${300 + domainIdx * 100}ms` }}
            >
              <h3 className="text-2xl font-semibold text-foreground mb-6 border-l-4 border-primary pl-4">
                {domain.domain}
              </h3>
              <div className="space-y-6">
                {domain.papers.map((paper, paperIdx) => (
                  <div
                    key={paperIdx}
                    className="bg-card border border-border rounded-lg p-6 hover:shadow-lg hover:scale-[1.02] transition-all duration-300"
                  >
                    <h4 className="text-xl font-bold text-foreground mb-2 leading-relaxed">{paper.title}</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      {paper.authors.map((author, idx) => (
                        <span key={idx}>
                          {author === "Yellu Siri" ? (
                            <span className="font-semibold text-foreground">{author}</span>
                          ) : (
                            author
                          )}
                          {idx < paper.authors.length - 1 && ", "}
                        </span>
                      ))}
                    </p>
                    <p className="text-sm font-medium text-primary mb-3">{paper.venue}</p>
                    <p className="text-muted-foreground mb-4 leading-relaxed">{paper.summary}</p>
                    <div className="flex flex-wrap gap-3">
                      <a
                        href={paper.links.paper}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View Paper
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* View All Publications Button */}
        <div className="text-center mt-12">
          <a
            href="https://scholar.google.com/citations?user=KgZ_LmYAAAAJ&hl=en"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              View all publications on Google Scholar
              <ExternalLink className="ml-2 w-4 h-4" />
            </Button>
          </a>
        </div>
      </div>
    </section>
  )
}
