"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { GraduationCap, Code, Lightbulb } from "lucide-react"
import { useEffect, useRef, useState } from "react"

const experiences = [
  {
    title: "Graduate Research Assistant",
    organization: "Kennesaw State University",
    description:
      "Developing hybrid ML pipelines for cancer image analysis and spatial pattern analytics, combining deep learning with traditional computer vision techniques.",
    icon: GraduationCap,
  },
  {
    title: "ML Engineer Intern",
    organization: "Pathsetter",
    description:
      "Built NLP chatbots and improved engagement and response accuracy through advanced natural language processing techniques.",
    icon: Code,
  },
  {
    title: "Research & Project Intern",
    organization: "DLRL",
    description:
      "Developed computer vision systems and automated dashboards for image processing and analysis workflows.",
    icon: Lightbulb,
  },
]

export function Experience() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="experience"
      className="py-20 sm:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-muted/30 to-background transition-colors duration-700"
    >
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12 sm:mb-16">
          <h2
            className={`text-3xl sm:text-4xl md:text-5xl font-bold mb-4 text-balance transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            Experience
          </h2>
          <div
            className={`w-20 h-1 bg-accent mx-auto rounded-full transition-all duration-700 delay-100 ${isVisible ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"}`}
          ></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {experiences.map((experience, index) => (
            <Card
              key={index}
              className={`border-none shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <experience.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg mb-1 text-balance">{experience.title}</CardTitle>
                <p className="text-sm text-accent font-medium">{experience.organization}</p>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed text-pretty">{experience.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
