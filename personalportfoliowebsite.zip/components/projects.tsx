"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Github, Globe } from "lucide-react"
import { useEffect, useRef, useState } from "react"
import Image from "next/image"

const projects = [
  {
    icon: "🤖",
    title: "AI-Agents (DermaScan Repo Assistant)",
    category: "AI/ML",
    tagline: "Intelligent RAG-based assistant for dermatology research and codebase navigation",
    highlights: [
      "Built multi-agent RAG system using LangChain and GPT-4 for medical document Q&A",
      "Integrated vector search with Pinecone for semantic retrieval of research papers",
      "Deployed interactive Streamlit app with real-time chat interface and code assistance",
    ],
    tools: ["Python", "LangChain", "GPT-4", "Pinecone", "Streamlit", "RAG", "Vector DB"],
    github: "https://github.com/SiriYellu/AI-Agents",
    demo: "https://ai-agents-dermascan.streamlit.app/",
    demoImage: "/images/dermascan-demo.gif",
  },
  {
    icon: "📊",
    title: "Pandemic Disparities Analysis",
    category: "Data Analytics",
    tagline: "Public health dashboard analyzing COVID-19 trends and demographic disparities",
    highlights: [
      "Designed Tableau dashboard integrating CDC data with 3K+ U.S. county demographics",
      "Uncovered healthcare access disparities correlating with 40% higher mortality rates",
      "Supported public health decision-making with accessible, interactive visualizations",
    ],
    tools: ["Tableau", "Python", "Public Health Analytics", "Statistical Analysis", "Data Integration"],
    github: "https://github.com/SiriYellu/pandemic-disparities-analysis",
    demo: "https://public.tableau.com/app/profile/gnana.prakash.reddy.donthi.reddy/viz/Covid-19CasesDeathsandMortalityRates/COVID-19casesdeathsmortalityrateshospitalbedavailability?publish=yes",
  },
  {
    icon: "🚚",
    title: "Logistics Optimization Dashboard",
    category: "Data Analytics",
    tagline: "Interactive Tableau dashboard for fleet efficiency and delivery analytics",
    highlights: [
      "Built comprehensive dashboard analyzing 50K+ delivery records and fleet metrics",
      "Identified root causes of 23% on-time delivery gap through geospatial analysis",
      "Visualized risk zones and bottlenecks improving logistics operations by 18%",
    ],
    tools: ["Python", "Tableau", "Pandas", "SQL", "Data Visualization", "Geospatial Analysis"],
    github: "https://github.com/SiriYellu/Logistics-Optimization-Dashboard",
    demo: "https://public.tableau.com/app/profile/siri.yellu/viz/LogisticsOptimizationDashboard/Dashboard1?publish=yes",
  },
  {
    icon: "🌍",
    title: "EcoDataAnalytics – Climate Change & Bird Migration",
    category: "Data Analytics",
    tagline: "Spatiotemporal analysis of climate patterns and avian migration trends",
    highlights: [
      "Analyzed 20+ years of NOAA climate data and eBird migration records (500K+ observations)",
      "Built Random Forest model predicting migration timing with 87% accuracy",
      "Created interactive visualizations supporting conservation policy recommendations",
    ],
    tools: ["Python", "Scikit-learn", "Tableau", "Plotly", "Pandas", "Geospatial Analysis"],
    github: "https://github.com/SiriYellu/EcoDataAnalytics",
    demo: "https://sites.google.com/view/ecodataanalytics/home",
  },
  {
    icon: "🩺",
    title: "DermaScan Android App",
    category: "AI/ML",
    tagline: "Mobile AI system for real-time skin lesion detection and classification",
    highlights: [
      "Developed Android app with TensorFlow Lite for on-device melanoma detection",
      "Achieved 92% accuracy using EfficientNet model trained on HAM10000 dataset",
      "Published research paper and deployed user-friendly mobile interface for clinical screening",
    ],
    tools: ["Android", "TensorFlow Lite", "Kotlin", "Deep Learning", "Computer Vision", "Mobile ML"],
    github: "https://github.com/SiriYellu/DermaScan_AndroidApp",
    demo: null,
  },
  {
    icon: "🧬",
    title: "Fruitfly Pose Tracking",
    category: "Computer Vision",
    tagline: "Advanced pose estimation system for behavioral neuroscience research",
    highlights: [
      "Implemented DeepLabCut-based pose tracking for fruit fly behavioral analysis",
      "Processed 10K+ video frames with multi-keypoint detection and temporal smoothing",
      "Enabled quantitative analysis of locomotion patterns for genetics research",
    ],
    tools: ["Python", "DeepLabCut", "OpenCV", "NumPy", "Deep Learning", "Computer Vision"],
    github: "https://github.com/SiriYellu/Fruitfly-pose-tracking",
    demo: null,
  },
  {
    icon: "👤",
    title: "VisiAttend – Facial Recognition Attendance System",
    category: "Computer Vision",
    tagline: "Automated attendance tracking using real-time facial biometric recognition",
    highlights: [
      "Developed real-time face recognition system with 95% accuracy using dlib and OpenCV",
      "Implemented liveness detection to prevent spoofing attacks and ensure security",
      "Built web-based admin dashboard for attendance management and reporting",
    ],
    tools: ["Python", "dlib", "OpenCV", "Face Recognition", "Flask", "Computer Vision"],
    github: "https://github.com/SiriYellu/VisiAttend-Automated-Attendance-System-Using-Facial-Biometrics",
    demo: null,
  },
  {
    icon: "💰",
    title: "FinGenius – Personal Finance Assistant",
    category: "AI/ML",
    tagline: "AI-powered chatbot for personalized financial advice and budget planning",
    highlights: [
      "Built conversational AI using GPT-3.5 with financial domain fine-tuning",
      "Integrated expense tracking API and generated personalized savings recommendations",
      "Deployed Streamlit interface with natural language understanding for financial queries",
    ],
    tools: ["Python", "OpenAI API", "Streamlit", "NLP", "FinTech", "Conversational AI"],
    github: "https://github.com/SiriYellu/FinGenius",
    demo: null,
  },
  {
    icon: "🔒",
    title: "CodexSafe – Code Security Analyzer",
    category: "AI/ML",
    tagline: "ML-based static analysis tool for detecting security vulnerabilities in code",
    highlights: [
      "Trained BERT-based model on 100K+ code samples to identify security flaws",
      "Achieved 89% precision in detecting SQL injection and XSS vulnerabilities",
      "Created VS Code extension for real-time security feedback during development",
    ],
    tools: ["Python", "BERT", "NLP", "Static Analysis", "Security", "VS Code Extension"],
    github: "https://github.com/SiriYellu/CodexSafe",
    demo: null,
  },
]

export function Projects() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.05 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const sortedProjects = [...projects].sort((a, b) => {
    if (a.demo && !b.demo) return -1
    if (!a.demo && b.demo) return 1
    return 0
  })

  return (
    <section ref={sectionRef} id="projects" className="py-20 sm:py-32 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12 sm:mb-16">
          <h2
            className={`text-3xl sm:text-4xl md:text-5xl font-bold mb-4 text-balance transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            Projects
          </h2>
          <p
            className={`text-muted-foreground max-w-2xl mx-auto mb-6 text-pretty transition-all duration-700 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            A showcase of AI/ML, computer vision, and data analytics projects spanning healthcare, research, and
            real-world applications
          </p>
          <div
            className={`w-20 h-1 bg-accent mx-auto rounded-full transition-all duration-700 delay-200 ${isVisible ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"}`}
          ></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedProjects.map((project, index) => (
            <Card
              key={index}
              className={`border-none shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-1 group flex flex-col ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
              style={{ transitionDelay: `${300 + index * 50}ms` }}
            >
              <CardHeader>
                <div className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl mb-3 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/30">
                  <span className="drop-shadow-[0_0_8px_rgba(59,130,246,0.5)]">{project.icon}</span>
                </div>
                <CardTitle className="text-xl mb-2 text-balance">{project.title}</CardTitle>
                <Badge variant="outline" className="w-fit mb-3 text-xs">
                  {project.category}
                </Badge>
                <CardDescription className="text-sm font-medium mb-3 text-foreground/80">
                  {project.tagline}
                </CardDescription>
                {project.demoImage && (
                  <div className="mb-4 rounded-lg overflow-hidden border border-border/50 bg-background/50">
                    <Image
                      src={project.demoImage || "/placeholder.svg"}
                      alt={`${project.title} demo`}
                      width={400}
                      height={300}
                      className="w-full h-auto object-cover"
                      unoptimized
                    />
                  </div>
                )}
                <CardDescription className="text-sm leading-relaxed">
                  <ul className="list-disc list-inside space-y-1.5">
                    {project.highlights.map((highlight, idx) => (
                      <li key={idx} className="text-pretty">
                        {highlight}
                      </li>
                    ))}
                  </ul>
                </CardDescription>
              </CardHeader>
              <CardContent className="mt-auto">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tools.map((tool, toolIndex) => (
                    <Badge key={toolIndex} variant="secondary" className="text-xs">
                      {tool}
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" asChild className="flex-1 bg-transparent">
                    <a href={project.github} target="_blank" rel="noopener noreferrer">
                      <Github className="h-4 w-4 mr-1" />
                      GitHub
                    </a>
                  </Button>
                  {project.demo && (
                    <Button size="sm" asChild className="flex-1">
                      <a href={project.demo} target="_blank" rel="noopener noreferrer">
                        <Globe className="h-4 w-4 mr-1" />
                        Demo
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div
          className={`text-center mt-12 transition-all duration-700 delay-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <Button size="lg" variant="outline" asChild>
            <a href="https://github.com/SiriYellu" target="_blank" rel="noopener noreferrer">
              <Github className="h-5 w-5 mr-2" />
              View All Projects on GitHub
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
