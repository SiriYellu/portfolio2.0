"use server"

export async function sendEmail(formData: FormData) {
  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const message = formData.get("message") as string

  // Create mailto link content
  const subject = `Portfolio Contact: Message from ${name}`
  const body = `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`

  // In a production environment, you would use an email service like:
  // - Resend (recommended)
  // - SendGrid
  // - Nodemailer with SMTP

  // For now, we'll return success to trigger the mailto link
  return {
    success: true,
    mailto: `mailto:syellu@students.kennesaw.edu?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`,
  }
}
